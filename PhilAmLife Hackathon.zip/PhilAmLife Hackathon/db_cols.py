# Run to create fresh start of the database (on empty database)
from __init__ import db
# create all columns inside database
db.create_all()
quit()
