from __init__ import app
app.run(debug=True, host="127.0.0.1", port=8000)
